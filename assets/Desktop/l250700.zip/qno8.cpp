#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "Enter the no of courses : ";
	cin >> n;
	double gp;
	double ch;
	double uppersum = 0;
	double lowersum = 0;
	double sgpa;
	for (int i = 1; i <= n; i++)
	{
		cout << "\n---------COURSE NO:" << i << "--------------" << endl;
		cout << "Enter the grade points of course " << i << " : ";
		cin >> gp;
		cout << "Enter credit hours of course " << i << " : ";
		cin >> ch;
		uppersum = uppersum + (gp * ch);
		lowersum = lowersum + ch;
	}
	sgpa = uppersum / lowersum;
	cout << "Semester Grade point average is :" << sgpa;
}