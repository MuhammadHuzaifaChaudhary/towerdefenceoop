//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	int Q;
//	int A;
//	int credit;
//	double assignabs = 0;      // sum of all absolutes of assignments 
//	double quizabs = 0;       // total absolutes of quizez
//	double projabs = 0;
//	double totalabs;
//	double weightoeach;
//	double gpa, totalgpa = 0, totalCreditHours = 0, avgGpa;
//	cout << "=========================================" << endl;
//	cout << "     Welcome to Fast GPA Calculator " << endl;
//	cout << "=========================================" << endl << endl;
//	do {
//		cout << "Enter no of courses : ";
//		cin >> n;
//		if (n <= 0)
//		{
//			cout << "Invalid no of courses!!\n";
//		}
//
//	} while (n <= 0);
//	for (int i = 1; i <= n; i++)
//	{
//		cout << "\n-----------Course no :" << i << "----------------\n";
//		double quiz = 0;
//		double qt = 0;
//
//		do {
//			cout << "Enter credit hours : ";
//			cin >> credit;
//			if (credit < 0 || credit>3)
//				cout << "Invalid Input!!\n";
//		} while (credit < 0 || credit>3);
//		cout << endl << "*****************Quizzes*************" << endl;
//		do {
//			cout << "Enter number of quizes  : ";
//			cin >> Q;
//			if (Q <= 0)
//			{
//				cout << "Invalid no of quizes !\n";
//			}
//		} while (Q <= 0);
//
//		for (int j = 1; j <= Q; j++)
//		{
//
//
//			double weight = 0;                     // we have to calculate absolute of each quiz than to add in total thats why we are making it zero again to avoid others quiz abs addition 
//			double totq;
//			double obtq;
//
//			do {
//				cout << "\nQuiz:" << j << "\nObtained marks:";
//				cin >> obtq;
//				if (obtq < 0)
//				{
//					cout << "Enter valid input!\n";
//				}
//			} while (obtq < 0);
//			do {
//				cout << "Total marks:";
//				cin >> totq;
//				if (totq <= 0 || totq < obtq)
//				{
//					cout << "Invalid Input \n";
//				}
//			} while (totq <= 0 || totq < obtq);
//			double weightoeach = 10.0 / Q;    // let there are 3 quiz each of 10 marks means each have weightage of 3.33
//			weight = obtq / totq * weightoeach;  // absolute of one quiz (example quiz have 10 mark and obtain mark is 5 than 10/5*3.33=1.665 absolute)
//			quizabs = weight + quizabs;        // total absolutes of all quizes
//		}
//		do {
//			cout << "Enter number of assignments : ";
//			cin >> A;
//			if (A <= 0)
//			{
//				cout << "Invalid no of assignments !\n";
//			}
//		} while (A <= 0);
//
//		for (int j = 1; j <= A; j++)
//		{
//			double weighta = 0;             // absolute one one assignment 
//			double tota;
//			double obta;
//			cout << endl << "************Assignment**************" << endl;
//			do {
//				cout << "Assignment:" << j << "Obtained marks:";
//				cin >> obta;
//				if (obta < 0)
//				{
//					cout << "Enter valid input!\n";
//				}
//			} while (obta < 0);
//			do {
//				cout << "Assignment:" << j << "total marks:";
//				cin >> tota;
//				if (tota <= 0 || tota < obta)
//				{
//					cout << "Invalid Input ";
//				}
//			} while (tota <= 0 || tota < obta);
//			double weightoeach = 10.0 / quiz;    // let there are 3 assignemnts  each of 10 marks means each have weightage of 3.33
//			weighta = obta / tota * weightoeach;  // absolute of one assignment 
//			assignabs = weighta + assignabs;       // total absolutes of all asignmenets 
//		}
//		cout << endl << "************Project**************" << endl;
//		double eachpro;
//		double obtpro;
//		double totpro;
//		do {
//			cout << "Enter obtain marks of project : ";
//			cin >> obtpro;
//			if (obtpro < 0)
//			{
//				cout << "Invalid marks!!\n";
//			}
//		} while (obtpro < 0);
//		do {
//			cout << "Enter total marks of project : ";
//			cin >> totpro;
//			if (totpro < 0)
//			{
//				cout << "Invalid marks\n";
//			}
//		} while (totpro < 0);
//		eachpro = (obtpro / totpro) * 10;
//		projabs += eachpro;
//
//		cout << endl << "************Sessional 1**************" << endl;
//		double obtsess1;
//		double totsess1;
//		double eachsess1;
//		do {
//			cout << "Enter obtain marks of sessional 1 : ";
//			cin >> obtsess1;
//			if (obtsess1 < 0)
//			{
//				cout << "Invalid marks!!\n";
//			}
//		} while (obtsess1 < 0);
//		do {
//			cout << "Enter total marks of sessional 1 : ";
//			cin >> totsess1;
//			if (totsess1 < 0 || totsess1 < obtsess1)
//			{
//				cout << "Invalid marks!!\n";
//			}
//		} while (totsess1 < 0 || totsess1 < obtsess1);
//		eachsess1 = (obtsess1 / totsess1) * 15;
//
//		double obtsess2;
//		double totsess2;
//		double eachsess2;
//		cout << endl << "************Sessional 2**************" << endl;
//		do {
//			cout << "Enter obtain marks of sessional 2 : ";
//			cin >> obtsess2;
//			if (obtsess2 < 0)
//			{
//				cout << "Invalid marks!!\n";
//			}
//		} while (obtsess2 < 0);
//		do {
//			cout << "Enter total marks of project : ";
//			cin >> totsess2;
//			if (totsess2 < 0 || totsess2 < obtsess2)
//			{
//				cout << "Invalid marks!!\n";
//			}
//		} while (totsess2 < 0 || totsess2 < obtsess2);
//		eachsess2 = (obtsess2 / totsess2) * 15;
//
//		double fobt, ftot, fabs;
//		cout << endl << "**************Final Exam**************" << endl;
//		do
//		{
//			cout << "Marks Obtained: ";
//			cin >> fobt;
//			cout << "Total Marks: ";
//			cin >> ftot;
//			if (fobt > ftot)
//			{
//				cout << "Invalid Input!!\n";
//			}
//		} while (fobt > ftot);
//
//		fabs = (fobt / ftot) * 40;
//
//		totalabs = quizabs + assignabs + projabs + eachsess1 + eachsess2 + fabs;
//
//		if (totalabs >= 90)
//		{
//			cout << "Grade = 'A+' \nCredit Points = 4.00" << endl;
//			gpa = 4.00;
//		}
//		else if (totalabs > 85)
//		{
//			cout << "Grade = 'A' \nCredit Points = 4.00" << endl;
//			gpa = 4.00;
//		}
//		else if (totalabs >= 82)
//		{
//			cout << "Grade = 'A-' \nCredit Points = 3.67" << endl;
//			gpa = 3.67;
//		}
//		else if (totalabs >= 78)
//		{
//			cout << "Grade = 'B+' \nCredit Points = 3.33" << endl;
//			gpa = 3.33;
//		}
//		else if (totalabs >= 74)
//		{
//			cout << "Grade = 'B' \nCredit Points = 3.00" << endl;
//			gpa = 3.00;
//		}
//		else if (totalabs >= 70)
//		{
//			cout << "Grade = 'B-' \nCredit Points = 2.67" << endl;
//			gpa = 2.67;
//		}
//		else if (totalabs >= 66)
//		{
//			cout << "Grade = 'C+' \nCredit Points = 2.33" << endl;
//			gpa = 2.33;
//		}
//		else if (totalabs >= 62)
//		{
//			cout << "Grade = 'C' \nCredit Points = 2.00" << endl;
//			gpa = 2.00;
//		}
//		else if (totalabs >= 58)
//		{
//			cout << "Grade = 'C-' \nCredit Points = 1.67" << endl;
//			gpa = 1.67;
//		}
//		else if (totalabs >= 54)
//		{
//			cout << "Grade = 'D+' \nCredit Points = 1.33" << endl;
//			gpa = 1.33;
//		}
//		else if (totalabs >= 50)
//		{
//			cout << "Grade = 'D' \nCredit Points = 1.00" << endl;
//			gpa = 1.00;
//		}
//		else
//		{
//			cout << "Grade ='F' \nCredit Points = 0.00" << endl;
//			gpa = 0.00;
//		}
//
//		totalgpa += gpa * credit;
//		totalCreditHours += credit;
//	}
//	avgGpa = totalgpa / static_cast<double>(totalCreditHours);
//	cout << "\nOverall GPA for " << n << " courses = " << avgGpa << endl;
//
//	if (avgGpa >= 4.00)
//		cout << "Grade = 'A+'" << endl;
//	else if (avgGpa >= 3.67)
//		cout << "Grade = 'A-'" << endl;
//	else if (avgGpa >= 3.33)
//		cout << "Grade = 'B+'" << endl;
//	else if (avgGpa >= 3.00)
//		cout << "Grade = 'B'" << endl;
//	else if (avgGpa >= 2.67)
//		cout << "Grade = 'B-'" << endl;
//	else if (avgGpa >= 2.33)
//		cout << "Grade = 'C+'" << endl;
//	else if (avgGpa >= 2.00)
//		cout << "Grade = 'C'" << endl;
//	else if (avgGpa >= 1.67)
//		cout << "Grade = 'C-'" << endl;
//	else if (avgGpa >= 1.33)
//		cout << "Grade = 'D+'" << endl;
//	else if (avgGpa >= 1.00)
//		cout << "Grade = 'D'" << endl;
//	else
//		cout << "Grade = 'F'" << endl;
//
//	return 0;
//
//}