//#include <iostream>
//using namespace std;
//
//int main() {
//    unsigned long long n;
//    do
//    {
//        cout << "Enter any 64-bit integer: ";
//        cin >> n;
//        if (n <= 0)
//        {
//            cout << "Invlaid Input!";
//        }
//    } while (n <= 0);
//
//    unsigned long long no1 = 0,no2 = 0;
//
//                                       // Check divisibility starting from 2 up to sqrt(num)
//    for (unsigned long long d = 2; d <=n/2; ++d) {
//        if (n % d == 0) {
//            no1 = d;
//            no2 = n / d;
//            break;
//        }
//    }
//
//    if (no1 != 0) {
//        cout << "The number can be expressed as a product of two primes:\n";
//        cout << "p = " << no1 << endl;
//        cout << "q = " << no2 << endl;
//    }
//    else {
//        cout << "No prime pair found(" << endl;
//    }
//
//    return 0;
//}