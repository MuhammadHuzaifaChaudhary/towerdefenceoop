//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	
//	do {
//		cout << "Enter the number of courses: ";
//		cin >> n;
//		if (n <= 0)
//		{
//			cout << "invalid no of courses ! try again " << endl;
//		}
//	} while (n <= 0);
//	double gp;
//	double ch;
//	double uppersum = 0;
//	double lowersum = 0;
//	for (int i = 1; i <= n; i++)
//	{
//		cout << "\n---------------Course:" << i << "------------------\n" << endl;
//		do {
//			cout << "Enter grade points : " << endl; 
//			cin >> gp;
//			if (gp < 0 || gp>4)
//			{
//				cout << "invalid gpa try again ! " << endl;
//			}
//
//		} while (gp < 0||gp>4);
//		do {
//			cout << "enter credit hour : " << endl;
//			cin >> ch;
//			if (ch <= 0)
//			{
//				cout << "enter valid credit hour try again !" << endl;
//			}
//		} while (ch <= 0);
//			uppersum = uppersum + (gp * ch);
//			lowersum = lowersum + ch;
//	}
//	cout << "Semester grade point average : " << uppersum / lowersum << endl;
//
//}