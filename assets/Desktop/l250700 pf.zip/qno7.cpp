//#include<iostream >
//using namespace std;
//int main()
//{
//	int n;
//	do
//	{
//		cout << "enter the height of kitte ";
//		cin >> n;
//		if (n <= 0)
//		{
//			cout << "Invalid Size!";
//		}
//	} while (n <= 0);
//	for (int i = 1; i <= n; i++)
//	{
//		for (int j = 1; j <= n - i; j++)
//		{
//			cout << "  ";
//		}
//		cout << "* ";
//		if (i != 1)
//		{
//			for (int j = 1; j <= 2 * i - 3; j++)
//			{
//				int width = 2 * i - 3;
//				if (i != n)
//				{
//					if (j == width / 2 + 1)
//						cout << "| ";
//					else
//						cout << "  ";
//				}
//				if (i == n)
//				{
//					if (j == width / 2 + 1)
//						cout << "| ";
//					else
//						cout << "_ ";
//				}
//			}
//			cout << "*";
//		}
//		cout << endl;
//	}
//	int wid = 2 * n - 3;                 // lower figure ki width is tarah se synchronize kar leni jo uper wohi neechay 
//	// uper 2*i-3 tha yani last par i==n tah 
//	for (int i = 2 * n - 2; i >= 1; i--)
//	{
//		for (int j = 1; j < 2 * n - i; j++)
//		{
//			cout << " ";
//		}
//		cout << "*";
//		for (int j = 1; j <= 2 * i - 3; j++)  // is tarah bas width may se i minus kar do to asaan kaam
//		{
//			if (j == i - 1)
//			{
//				cout << "|";
//			}
//
//			else
//			{
//				cout << " ";
//			}
//		}
//		if (i != 1) {
//			cout << "*";
//		}
//		cout << endl;
//	}
//}