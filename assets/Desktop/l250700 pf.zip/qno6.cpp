//#include<iostream>
//using namespace std;
//int main()
//{
//    int d, m, y;
//    cout << "----------------- Date of Birth -------------------\n";
//    do {
//        cout << "Enter day   : ";
//        cin >> d;
//        if (d < 1 || d>31)
//            cout << "invalid day ! " << endl;
//    } while (d < 1 || d>31);
//
//    do {
//        cout << "Enter month : ";
//        cin >> m;
//        if (m < 1 || m>12)
//            cout << "Invalid month!";
//    } while (m < 1 || m>12);
//
//    do {
//    cout << "Enter year  : ";
//    cin >> y;
//    if (y <= 0)
//        cout << "Invalid Year" << endl;
//    } while (y <= 0);
//
//    // digits seperate 
//    int d1 = d / 10;
//    int d2 = d % 10;
//    int m1 = m / 10;
//    int m2 = m % 10;
//    int y1 = y / 1000;
//    int y2 = (y / 100) % 10;
//    int y3 = (y / 10) % 10;
//    int y4 = y % 10;
//
//    // Print 8 lines for pattern height because every no is taking 8 rows 
//    for (int i = 1; i <= 8; i++)
//    {
//        int j = 1;
//        for (; j <= 8; j++)         //for every  value of i the loop runs 8 times and decides the number(e.g d1 ,d2) and prints the part of all the numbers 
//            // means for i=1 the inner loop prints  the top parts of all numbers and then so on 
//        {
//            int num;
//            if (j == 1) num = d1;
//            else if (j == 2) num = d2;
//            else if (j == 3) num = m1;
//            else if (j == 4) num = m2;
//            else if (j == 5) num = y1;
//            else if (j == 6) num = y2;
//            else if (j == 7) num = y3;
//            else num = y4;
//
//            // print pattern of current digit
//            if (num == 0)
//            {
//                if (i == 1) cout << "  /$$$$$$  ";
//                if (i == 2) cout << " /$$$_  $$ ";
//                if (i == 3) cout << "| $$$$\\ $$ ";
//                if (i == 4) cout << "| $$ $$ $$ ";
//                if (i == 5) cout << "| $$\\ $$$$ ";
//                if (i == 6) cout << "| $$\\  $$$ ";
//                if (i == 7) cout << "|  $$$$$$/ ";
//                if (i == 8) cout << " \\______/  ";
//            }
//            if (num == 1)
//            {
//                if (i == 1) cout << " /  $$ ";
//                if (i == 2) cout << "/ $$$$ ";
//                if (i == 3) cout << "|_  $$ ";
//                if (i == 4) cout << "  | $$ ";
//                if (i == 5) cout << "  | $$ ";
//                if (i == 6) cout << "  | $$ ";
//                if (i == 7) cout << "/$$$$$$";
//                if (i== 8) cout << "|_____/";
//            }
//            if (num == 2)
//            {
//                if (i == 1) cout << "  /$$$$$$$  ";
//                if (i == 2) cout << " /$$__  $$  ";
//                if (i == 3) cout << "|__/  \\ $$  ";
//                if (i == 4) cout << "   /$$$$$/  ";
//                if (i == 5) cout << "  /$$___/   ";
//                if (i == 6) cout << " / $$       ";
//                if (i == 7) cout << "|  $$$$$$$  ";
//                if (i == 8) cout << "|________/  ";
//            }
//            if (num == 3)
//            {
//                if (i == 1) cout << "  /$$$$$$$   ";
//                if (i == 2) cout << " /$$__  $$   ";
//                if (i == 3) cout << "      \\ $$   ";
//                if (i == 4) cout << "  /$$$$$$/   ";
//                if (i == 5) cout << " |____  $$   ";
//                if (i == 6) cout << "      \\ $$   ";
//                if (i == 7) cout << "  /$$$$$$/   ";
//                if (i == 8) cout << " |______/    ";
//            }
//            if (num == 4)
//            {
//                if (i == 1) cout << " /$$   /$$";
//                if (i == 2) cout << "| $$  | $$";
//                if (i == 3) cout << "| $$  | $$";
//                if (i == 4) cout << "| $$$$$$$$";
//                if (i == 5) cout << "|_____  $$";
//                if (i == 6) cout << "      | $$";
//                if (i == 7) cout << "      | $$";
//                if (i == 8) cout << "      |__/";
//            }
//               if (num == 5)
//               {
//                   if (i == 1) cout << "  /$$$$$$$  ";
//                   if (i == 2) cout << " | $$__ $$  ";
//                   if (i == 3) cout << " | $$       ";
//                   if (i == 4) cout << " | $$$$$$$  ";
//                   if (i == 5) cout << " |_____ $$  ";
//                   if (i == 6) cout << "      \\ $$ ";
//                   if (i == 7) cout << "  /$$$$$$/  ";
//                   if (i == 8) cout << " |______/   ";
//               }
//               if (num == 6)
//              { 
//               if (i == 1) cout << "  /$$$$$$ ";
//               if (i == 2) cout << " /$$   $$ ";
//               if (i == 3) cout << "| $$      ";
//               if (i == 4) cout << "| $$$$$$$ ";
//               if (i == 5) cout << "| $$    $$";
//               if (i == 6) cout << "| $$    $$";
//               if (i == 7) cout << "|  $$$$$$/";
//               if (i == 8) cout << " \\______/ ";
//               }
//               if (num == 7)
//               {
//                   if (i == 1) cout << " /$$$$$$$$";
//                   if (i == 2) cout << "|_____ $$/";
//                   if (i == 3) cout << "     /$$/ ";
//                   if (i == 4) cout << "    /$$/  ";
//                   if (i == 5) cout << "   /$$/   ";
//                   if (i == 6) cout << "  /$$/    ";
//                   if (i == 7) cout << " /$$/     ";
//                   if (i == 8) cout << "/__/      ";
//               }
//               if (num == 8)
//               {
//                   if (i == 1) cout << "  /$$$$$ \\  ";
//                   if (i == 2) cout << " /$$__  $$  ";
//                   if (i == 3) cout << "| $$  \\ $$  ";
//                   if (i == 4) cout << " \\$$$$$$/   ";
//                   if (i == 5) cout << " /$$__  $$  ";
//                   if (i == 6) cout << "| $$  \\ $$  ";
//                   if (i == 7) cout << " \\$$$$$$/   ";
//                   if (i == 8) cout << "  \\____/    ";
//               }
//               if (num == 9)
//               {
//                   if (i == 1) cout << "  /$$$$$$$  ";
//                   if (i == 2) cout << " /$$__  $$  ";
//                   if (i == 3) cout << "| $$  \\ $$  ";
//                   if (i == 4) cout << "|  $$$$$$/  ";
//                   if (i == 5) cout << " \\____  $$  ";
//                   if (i == 6) cout << "      \\ $$  ";
//                   if (i == 7) cout << "  /$$$$$$/  ";
//                   if (i == 8) cout << " |______/   ";
//               }cout << " ";
//        }
//        cout << endl;
//    }
//}