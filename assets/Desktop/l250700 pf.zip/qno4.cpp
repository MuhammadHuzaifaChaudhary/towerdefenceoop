//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	do {
//		cout << "enter the size of shape ";
//		cin >> n;
//		if (n <= 0)
//		{
//			cout << "invalid size!";
//		}
//	} while (n <= 0);
//	for (int i = 1; i <= n; i++)
//	{
//		for (int j = 1; j <= n - i; j++)
//		{
//			cout << " ";
//		}
//		if (i == 1)
//		{
//			cout << ".";
//		}
//		if (i != 1 || i == n)     // can also use else instead of this condition 
//		{
//			cout << "/";         // chahay i==n ho ya phr i!=n  (/) start may  ana hi hay 
//			for (int j = 1; j <= 2 * i - 3; j++) // its inner spaces or dash(_) loop. i==n kay lia bas dash aa jay ga 
//			{
//				if (i != n)
//				{
//					cout << " ";
//				}
//				if (i == n)
//				{
//					cout << "_";
//				}
//			}
//			cout << "\\";
//		}
//		cout << endl;
//	}
//	int space = 2 * n - 2;
//	for (int i = 1; i <= n; i++)
//	{
//		cout << "|";
//		for (int j = 1; j < space; j++)
//		{
//			if (i == n / 2 + 1 && j == space / 2)
//			{
//				cout << "_";
//			}
//			else if ((i > ((n / 2) + 1)) && ((j == (space / 2) - 1) || (j == (space / 2 + 1))))
//				cout << "|";
//			else if (i == n)
//				cout << "_";
//			else
//				cout << " ";
//
//		}
//		cout << "|";
//		cout << endl;
//
//	}
//
//}