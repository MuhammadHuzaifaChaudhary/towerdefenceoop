//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	do
//	{
//		cout << "Enter size of shape :";
//		cin >> n;
//		if (n <= 0)
//		{
//			cout << "Invalid size!";
//		}
//	} while (n <= 0);
//	for (int i = 1; i <= n; i++)
//
//	{
//		for (int j = 1; j <= n - i; j++)
//		{
//			cout << "  ";
//		}
//		for (int j = 1; j < i; j++)   
//		{
//			cout << "* ";   
//		}
//		for (int j = 1; j <= i; j++)
//		{
//			cout << "* ";
//		}
//		cout << endl;
//	}
//	for (int i = 1; i <= n; i++)
//	{
//		for (int j = 1; j <= i; j++)
//		{
//			cout << "  ";
//		}
//		for (int j = n-1; j > i; j--)  //idr bhi aik iterationn kam hay is may ya ti j>=i-1 kar lo ya to  j>i kar lo
//		{
//			cout << "* ";
//		}
//		for (int j = n-1; j >= i; j--)  // is ki iteration ziada hay aik 
//		{
//			cout << "* ";
//		}cout << endl;
//
//	}
//}