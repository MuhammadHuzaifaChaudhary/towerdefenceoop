//#include<iostream>
//using namespace std;
//int main()
//{
//	int d1, m1, y1, min1, h1, s1;
//	int febdays1;
//	int days1;
//	int febdays2;
//	int days2;
//	int d2, m2, y2, min2, h2, s2;
//	cout << "----------first date ----------------" << endl;
//	do
//	{
//		cout << "Enter year ";
//		cin >> y1;
//		if (y1 <= 0)
//		{
//			cout << " invalid year! enter year :";
//		}
//	} while (y1 <= 0);
//	if ((y1 % 4 == 0 && y1 % 100 != 0) || (y1 % 400 == 0))    // check leap year or not
//	{
//		febdays1 = 29;
//	}
//	else 
//	{
//		febdays1 = 28;
//	}
//	do
//	{
//		cout << " Enter month :";
//		cin >> m1;
//		if (m1 < 1 || m1>12)
//			cout << "invalid month try again !";
//	} while (m1 < 1 || m1>12);
//	if (m1 == 1 || m1 == 3 || m1 == 5 || m1 == 7 || m1 == 8 || m1 == 10 || m1 == 12)
//	{
//		days1 = 31;
//	}
//	if (m1 == 4 || m1 == 6 || m1 == 9 || m1 == 11)
//	{
//		days1= 30;
//	}
//	else
//		days1 = febdays1;
//	do
//	{
//		cout << "enter day :";
//		cin >> d1;
//		if (d1 < 1 || d1>days1)                      // greater than days1 is lia kiya kun kay user agr month 11 enter to karay 
//			// to days to 30 hon gay is lia d1>31 nahi use kar saktay 
//			cout << "invalid day try again!";
//	} while (d1 < 1 || d1>days1);
//	do 
//	{
//		cout << " Enter minutes :";
//		cin >> min1;
//		if (min1 < 0 || min1>59)
//		{
//			cout << "Invalid minute !enter minute :";
//		}
//	} while (min1 < 0 || min1>59);
//	do
//	{
//		cout << "Enter hours :";
//			cin >> h1;
//			if (h1 < 0||h1>23)
//			{
//				cout << " Invalid hour!Enter hour";
//			}
//	} while (h1 < 0||h1>23);
//		do 
//		{
//			cout << "Enter seconds:";
//			cin >> s1;
//			if (s1 < 0||s1>59)
//			{
//				cout << "Invalid seconds ! enter sec:";
//			}
//		} while (s1 < 0||s1>59);
//
//		cout << "----------second date ----------------" << endl;
//		do
//		{
//			cout << "Enter year ";
//			cin >> y2;
//			if (y2 <= 0)
//			{
//				cout << " invalid year! enter year :" << endl;
//			}
//		} while (y2 <= 0);
//		if ((y2 % 4 == 0 && y2 % 100 != 0) || (y2 % 400 == 0))
//		{
//			febdays2 = 29;
//		}
//		else
//		{
//			febdays2 = 28;
//		}
//		do
//		{
//			cout << " Enter month :";
//			cin >> m2;
//			if (m2 < 1 || m2>12)
//				cout << "invalid month try again !";
//		} while (m2 < 1 || m2>12);
//		if (m2 == 1 || m2 == 3 || m2 == 5 || m2 == 7 || m2 == 8 || m2 == 10 || m2 == 12)
//		{
//			days2 = 31;
//		}
//		if (m2 == 4 || m2 == 6 || m2 == 9 || m2 == 11)
//		{
//			days2 = 30;
//		}
//		else
//			days2 = febdays2;
//		do
//		{
//			cout << "enter day :";
//			cin >> d2;
//			if (d2 < 1 || d2>days2)
//				cout << "invalid day try again!";
//		} while (d2 < 1 || d2>days2);
//		do 
//		{
//			cout << " Enter minutes :";
//			cin >> min2;
//			if (min2 < 0 || min2>59)
//			{
//				cout << "Invalid minute!Enter year:";
//			}
//		} while (min2 < 0 || min2>59);
//		do 
//		{
//			cout << "Enter hours :";
//			cin >> h2;
//			if (h2 < 0 || h2>23)
//			{
//				cout << " Invalid hour!Enter hour:";
//			}
//		} while (h2 < 0 || h2>23);
//		do 
//		{
//			cout << "Enter seconds:";
//			cin >> s2;
//			if (s2 < 0 || s2>59)
//			{
//				cout << "Invalid seconds ! enter sec: ";
//			}
//		} while (s2 < 0 || s2>59);
//		if (s2 < s1) // have to apply condition first then do difference 
//		{
//			s2 = s2 + 60;
//			min2--;
//		}
//		int sec = s2 - s1;
//		if (min2 < min1)
//		{
//			min2 = min2 + 60;
//			h2--;
//		}
//		int minute = min2 - min1;
//
//		if (h2 < h1)     
//		{
//			h2 = h2 + 24;
//			d2--;
//		}
//		int hour = h2 - h1;
//		
//		if (d2 < d1)
//		{
//			m2--;       // we have to add days of previous month so first move to previous one then check which 
//			          //month it is then take borrow from it (its days )
//			if (m2 < 1) 
//			{ m2 = 12;    // suppose hamaray pass january tha to m2-- se to aik month peechay ana hya to january se peechay to december ay ga 
//			             // is lia aik year bhi kum kar dia . 
//			   y2--; 
//			}
//			int feb;
//			if((y2 % 4 == 0 && y2 % 100 != 0) || (y2 % 400 == 0))
//			{
//				feb=29;
//			}
//			else
//			{
//				feb=28;
//			}
//			int adddays;
//			if (m2 == 1 || m2 == 3 || m2 == 5 || m2 == 7 || m2 == 8 || m2 == 10 || m2 == 12)
//			{
//				adddays = 31;
//			}
//			else if (m2 == 4 || m2 == 6 || m2 == 9 || m2 == 11)
//			{
//				adddays = 30;
//			}
//			else
//			{
//				adddays = feb;
//			}
//			d2 =d2+adddays;
//		}
//		int din = d2 - d1;
//		if (m2 < m1)
//		{
//			m2 = m2 + 12;
//			y2--;
//		}
//		int month = m2 - m1;
//		int year=y2 - y1;
//		cout << "--------------------DURATION B/W DATES--------------------" << endl;
//		if (year != 0)
//		{
//			cout << "YEARS:" << year<< endl;
//		}
//		if (month != 0)
//		{
//			cout << "MONTH:" << month << endl;
//		}
//		if (din != 0)
//		{
//			cout << "DAYS:" << din << endl;
//		}
//		if (hour != 0)
//		{
//			cout << "HOURS:" << hour << endl;
//		}
//		if (minute != 0)
//		{
//			cout << "MINUTE:" << minute << endl;
//		}
//		if (sec != 0)
//		{
//			cout << "SECONDS:" << sec << endl;
//		}
//}
