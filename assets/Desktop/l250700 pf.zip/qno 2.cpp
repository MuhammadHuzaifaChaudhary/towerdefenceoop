//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	do {
//		cout << " enter size of shape:";
//		cin >> n;
//		if (n <= 0)
//		{
//			cout << "Invalid size!";
//		}
//	} while (n <= 0);
//	for (int i = 1; i <= n; i++)        // for top triangle 
//	{
//		for (int j = 1; j <= n; j++)
//		{
//		     if (i == 1)               // at top line I just have to print (* )
//		     {
//				cout << "* ";
//		     }
//		} 
//		if (i != 1)
//		{
//			for (int j = 1; j <= i - 1; j++)
//			{
//				cout << " ";
//
//			} cout << "*";
//			for (int j = 1; j <= 2*(n-1-i)+1; j++)
//			{
//				cout << " ";
//
//			}
//			if (i != n)
//			{
//				cout << "*";
//			}
//		} 
//		cout << endl;
//
//	}                             // here it is for bottom triangle 
//	for (int i = 2; i <= n; i++)
//	{
//		if (i != n)              
//		{
//			for (int j = 1; j <= n - i; j++)
//			{
//				cout << " ";
//		    }	cout << "*";
//
//	for (int j = 1; j <= 2 * i - 3;j++)
//			{
//				cout << " ";
//			}
//			cout << "*";
//		}  
//		if(i==n)                      // here at last line i have to print a star and space side by side 
//		for (int j = 1; j <=n;j++)
//		{
//			cout << "* ";
//		}
//		cout << endl;
//	}
//}