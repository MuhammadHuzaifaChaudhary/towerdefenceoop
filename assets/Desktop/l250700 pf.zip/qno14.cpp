//#include<iostream>
//using namespace std;
//int main()
//{
//	int n;
//	int Q;
//	int A;
//	double assignabs = 0;      // sum of all absolutes of assignments 
//	double quizabs = 0;       // total absolutes of quizez
//	double projabs = 0;
//	do {
//		cout << "enter no of courses : ";
//		cin >> n;
//		if (n <= 0)
//		{
//			cout << "Invalid no of courses !";
//		}
//
//	} while (n <= 0);
//	for (int i = 1; i <= n; i++)
//	{
//		cout << "\n-----------Course no :" << i << "----------------";
//		double quiz = 0;
//		double qt = 0;
//		do {
//			cout << "enter number of quizez  : ";
//			cin >> Q;
//			if (Q <= 0)
//			{
//				cout << "Invalid no of quizes !";
//			}
//		} while (Q <= 0);
//		 
//		for (int j = 1; j <= Q; j++)
//		{
//			double weight = 0;                     // we have to calculate absolute of each quiz than to add in total thats why we are making it zero again to avoid others quiz abs addition 
//			double totq;
//			double obtq;
//			do {
//				cout << "Quiz:" << j << "Obtained marks:";
//				cin >> obtq;
//				if (obtq < 0)
//				{
//					cout << "enter valid input!";
//				}
//			} while (obtq < 0);
//			do {
//				cout << "Quiz" << j << "total marks:";
//				cin >> totq;
//				if (totq <= 0)
//				{
//					cout << "Invalid Input ";
//				}
//			} while (totq <= 0);
//			double weightoeach = 10.0 / Q;    // let there are 3 quiz each of 10 marks means each have weightage of 3.33
//			weight = obtq / totq * weightoeach;  // absolute of one quiz (example quiz have 10 mark and obtain mark is 5 than 10/5*3.33=1.665 absolute)
//			quizabs = weight + quizabs;        // total absolutes of all quizes
//		} 
//		do {
//			cout << "enter number of assignments  : ";
//			cin >> A;
//			if (A <= 0)
//			{
//				cout << "Invalid no of courses !";
//			}
//		} while (A <= 0);
//		               
//		for (int j = 1; j <= A; j++)
//		{
//			double weighta = 0;             // absolute one one assignment 
//			double tota;
//			double obta;
//			do {
//				cout << "Assignment:" << j << "Obtained marks:";
//				cin >> obta;
//				if (obta < 0)
//				{
//					cout << "enter valid input!";
//				}
//			} while (obta < 0);
//			do {
//				cout << "Quiz" << j << "total marks:";
//				cin >> tota;
//				if (tota <= 0)
//				{
//					cout << "Invalid Input ";
//				}
//			} while (tota <= 0);
//			double weightoeacha = 10.0 / quiz;    // let there are 3 assignemnts  each of 10 marks means each have weightage of 3.33
//			weighta = obta / tota * weightoeacha;  // absolute of one assignment 
//			assignabs = weighta + assignabs;       // total absolutes of all asignmenets 
//		}
//	double eachpro;
//	double obtpro;
//	double totpro;
//	do {
//		cout << "Enter obtain marks of project : ";
//		cin >> obtpro;
//		if(obtpro<0)
//		{
//			cout << "Invalid marks";
//		}
//	} while (obtpro < 0);
//	do {
//		cout << "Enter total marks of project : ";
//		cin >> totpro;
//		if (totpro < 0)
//		{
//			cout << "Invalid marks";
//		}
//	} while (totpro < 0);
//	eachpro = (obtpro / totpro) * 10;
//	projabs += eachpro;
//	double obtsess1;
//	double totsess1;
//	double eachsess1;
//	do {
//		cout << "Enter obtain marks of sessional 1 : ";
//		cin >> obtsess1;
//		if (obtsess1 < 0)
//		{
//			cout << "Invalid marks";
//		}
//	} while (obtsess1 < 0);
//	do {
//		cout << "Enter total marks of project : ";
//		cin >> totsess1;
//		if (totsess1 < 0)
//		{
//			cout << "Invalid marks";
//		}
//	} while (totsess1 < 0);
//	eachsess1 = (obtsess1 / totsess1) * 15;
//    
//	}
//	
//}