#include<iostream>
using namespace std;
int main()
{
	int n;
	do {
		cout << "enter size of pattern : ";
		cin >> n;
		if (n <= 0)
		{
			cout << "invalid size!";
		}
	} while (n <= 0);
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= 2 * n; j++)
		{
			if ((i == 1 || i == n) || (i > 1 && i < n && j == 1) || (i > 1 && i < n && j == 2 * n))
				cout << "*";
			else if ((j == (2 * n) / 2 + 1) && (i == n / 2 + 1))
				cout << 0;
			else
				cout << " ";
		}
		for (int j = 1; j <= n; j++)
		{
			if (i == n / 2 + 1)
				cout << "*";
			else
				cout << " ";
		}
		for (int j = 1; j <= 2 * n; j++)
		{
			if ((i == 1 || i == n) || (i > 1 && i < n && j == 1) || (i > 1 && i < n && j == 2 * n))
				cout << "*";
			else if ((j == (2 * n) / 2 + 1) && (i == n / 2 + 1))
				cout << 0;
			else
				cout << " ";
		}
		cout << endl;
	}
	int space = (2 * n) + n / 2 + 1;
	for (int i = 1; i <= n/2; i++)
	{
		for (int j = 1; j <= space; j++)
		{
			if (j == space)
				cout << "|";
			else
				cout << " ";
		}
		cout << endl;
	}
	for (int i = 1; i <= n/2+2; i++)
	{
		for (int j = 1; j < 2 * n+i; j++)
		{
			cout << " ";
		}
			if ( i == 1)
			{
				for (int m = 1; m <= 2*n-3*i; m++)
				{
					cout << "_";
				}
				cout << endl;
			}
			if (i != 1)
			{
				cout << "\\";
				for (int m = 1; m <= 2 * (n - i - 1); m++)
				{
					cout << " ";
				}
				cout << "/";
			}
			cout << endl;
	}
	for (int i = 1; i <= 2 * n; i++)
	{
		cout << " ";
	}
	cout << endl;
	for (int i = 1; i <= 2 * n; i++)
	{
		cout << " ";
	}
	cout << "\\";
	for (int i = 1; i <= n; i++)
	{
		cout << ".";
	}
	cout << "/";
}
