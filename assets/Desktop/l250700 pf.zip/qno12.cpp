//#include<iostream>
//using namespace std;
//int main() {
//	char ch;
//	int coff_price, es, wc, cups, add_price;
//	int re_order;
//	int user_id = 1;
//	do {
//		cout << "Welcome to Fast Hub" << endl;
//		cout << "Enter Required Coffee" << endl << "e=Espresso" << ',' << "c = Cappuccino" << ',' << "l = Latte" << endl;
//		cin >> ch;
//		while (ch != 'e' && ch != 'E' && ch != 'l' && ch != 'L' && ch != 'c' && ch != 'C') {
//			cout << "Invalid Choice" << endl;
//			cout << "Enter  E/e or c/C or l/L only" << endl;
//			cin >> ch;
//		}
//
//		if (ch == 'e' || ch == 'E')
//		{
//			coff_price = 230;
//			cout << "Espresso Price=" << coff_price << endl;
//		}
//		else if (ch == 'c' || ch == 'C')
//		{
//			coff_price = 250;
//			cout << " Cappucinno Price=" << coff_price << endl;
//		}
//		else if (ch == 'l' || ch == 'L')
//		{
//			coff_price = 150;
//			cout << " Latte Price=" << coff_price << endl;
//		}
//		else
//			cout << "Invalid Choice" << endl;
//		do{
//		cout << "Please enter number of cups=" << endl;
//		cin >> cups;
//		
//			 if (cups > 0)
//				add_price = coff_price * cups;
//			 else
//				 cout << "Invalid Input!" << endl;
//		} while (cups <=0);
//		int Dumychoice;
//		cout << "Press 1 to get extra sugar(Rs.30)" << endl;
//		cin >> Dumychoice;
//		if (Dumychoice == 1) {
//			int es;
//			do {
//				cout << " Enter Number of extra sugars you want:" << endl;
//				cin >> es;
//				if (es > 0)
//					add_price = add_price + (30 * es);
//				else
//					cout << "enter positive values only" << endl;
//			} while (es < 0);
//		}
//		int creamchoice;
//		cout << "Press 2 to get whipped cream(Rs.50):" << endl;
//		cin >> creamchoice;
//		if (creamchoice == 2) {
//			int wc;
//			do {
//				cout << "Enter number of extra whipped cream you want:" << endl;
//				cin >> wc;
//				if (wc > 0)
//					add_price = add_price + (50 * wc);
//				else
//					cout << "Enter positive values only" << endl;
//			} while (wc < 0);
//		}
//
//		int sercharge, tot_bill;
//		sercharge = 0.20 * add_price;
//		tot_bill = sercharge + add_price;
//		cout << "---------------------------------------------" << endl;
//		cout << "User ID=" << user_id << endl;
//		cout << "---------------------------------------------" << endl;
//		cout << "Total Price=Rs." << add_price << endl;
//		cout << "GST(General Sales Tax)=Rs." << sercharge << endl;
//		cout << "Sub-Total Price(Incuding 20% Service Tax)=Rs." << tot_bill << endl;
//		cout << "---------------------------------------------" << endl;
//		user_id++;
//		cout << "Do you want to order again. press 1 for re-order" << endl;
//		cin >> re_order;
//	} while (re_order==1);
//	cout << "Thanks for visiting Fast Hub" << endl;
//	return 0;
//}
