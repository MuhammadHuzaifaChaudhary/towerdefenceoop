//#include<iostream>
//#include<iomanip>
//using namespace std;
//int main()
//{
//	int n;
//	do {
//		cout << "enter no of rows ";
//		cin >> n;
//		if (n <= 0)
//		{
//			cout << "invalid no of rows!";
//		}
//	} while (n <= 0);
//	{
//		for (int i = 1; i <= n; i++)
//		{
//			int k = 1;
//			for (int j = 1; j <= n - i; j++)
//			{
//				cout << " ";
//			}
//			for (int j = 1; j <= i; j++)
//			{
//				cout <<" " << k;
//				k = k * (i - j) / j;
//			}cout << endl;
//	    }
//	}
//}